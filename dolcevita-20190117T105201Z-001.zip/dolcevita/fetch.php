<?php
include_once("connection.php");

$db = new dbObj();
$connString = $db->getConnstring();

if ($result = $connString->query("SELECT tasks_status FROM tasks WHERE tasks_status = 'remaining'")) {
    $rem = $result->num_rows;
}
if ($result = $connString->query("SELECT tasks_status FROM tasks WHERE tasks_status = 'completed'")) {
    $com = $result->num_rows;
}
$row_cnt = $rem+$com;
$data = array(
        "total" => $row_cnt,
        "rem" => $rem,
        "com" => $com
    );
    echo json_encode($data);
?>
    
