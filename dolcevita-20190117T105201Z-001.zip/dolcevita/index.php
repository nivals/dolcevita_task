<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Dolcevita Tasks</title>
        <link rel="stylesheet" href="dist/bootstrap.min.css" type="text/css" media="all">
        <link href="dist/dolcevita/index.css" rel="stylesheet" type="text/css"/>
        <link href="dist/jquery.bootgrid.css" rel="stylesheet" />
        <script src="dist/jquery-1.11.1.min.js"></script>
        <script src="dist/bootstrap.min.js"></script>
        <script src="dist/jquery.bootgrid.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <!-- Bootstrap Date-Picker Plugin -->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
        <script src="dist/dolcevita/index.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="dash">
            <h1>Dolcevita Tasks</h1>
        </div>
        <div class="container center ">
            <div class="row">
                <div class="col-sm-12 " >
                    <div class="well clearfix ">
                        <div class="pull-left">
                            <ul class="list-inline">
                                <li class="list-inline-item">Total Tasks<span class="badge" id="total"></span></li>
                                <li class="list-inline-item">Task Completed<span class="badge" id="com"></span></li>
                                <li class="list-inline-item">Task Remaining<span class="badge" id="rem"></span></li>
                            </ul>
                        </div>
                        <div class="pull-right">
                            <button type="button" class="btn btn-xs btn-primary" id="command-add" data-row-id="0">
                                <span class="glyphicon glyphicon-plus"></span> Add Task
                            </button>

                        </div>
                    </div>
                    <table id="tasks_grid" class="table table-condensed table-hover table-striped table-responsive" width="60%" cellspacing="0" data-toggle="bootgrid">
                        <thead>
                            <tr>
                                <th data-column-id="id" data-type="numeric" data-identifier="true">#</th>
                                <th data-column-id="tasks_name">Name</th>
                                <th data-column-id="tasks_status">Status</th>
                                <th data-column-id="tasks_date">Date</th>
                                <th data-column-id="commands" data-formatter="commands" data-sortable="false">Commands</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>

        </div>

        <div id="add_model" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Add Tasks</h4>
                    </div>
                    <div class="modal-body">
                        <form method="post" id="frm_add">
                            <input type="hidden" value="add" name="action" id="action">
                            <div class="form-group">
                                <label for="name" class="control-label">Name:</label>
                                <input type="text" class="form-control" id="name" name="name"/>
                            </div>
                            <div class="form-group">
                                <label for="status" class="control-label">Status:</label>
                                <select class="form-control" id="status" name="status">
                                    <option>completed</option>
                                    <option>remaining</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="status" class="control-label">Date:</label>
                                <input class="form-control date" id="date" name="date" placeholder="yyyy-mm-dd" type="text"/>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="button" id="btn_add" class="btn btn-primary">Save</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div id="edit_model" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Edit Tasks</h4>
                    </div>
                    <div class="modal-body">
                        <form method="post" id="frm_edit">
                            <input type="hidden" value="edit" name="action" id="action">
                            <input type="hidden" value="0" name="edit_id" id="edit_id">
                            <div class="form-group">
                                <label for="name" class="control-label">Name:</label>
                                <input type="text" class="form-control" id="edit_name" name="edit_name"/>
                            </div>
                            <div class="form-group">
                                <label for="status" class="control-label">Status:</label>
<!--                                <input type="text" class="form-control" id="edit_status" name="edit_status"/>-->
                                <select class="form-control" id="edit_status" name="edit_status">
                                    <option>completed</option>
                                    <option>remaining</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="status" class="control-label">Date:</label>
<!--                                <input type="text" class="form-control" id="edit_date" name="edit_date"/>-->
                                <input class="form-control date" id="edit_date" name="edit_date"placeholder="yyyy-mm-dd" type="text"/>
                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="button" id="btn_edit" class="btn btn-primary">Save</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>

